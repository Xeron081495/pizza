<footer>
	<div class="ancla float-left">
		<div id="menucel"class="punto"></div>
	</div>
	<nav id="menu-celu" class="d-lg-none">
		   <a class="opcion-menu" href="./">Inicio</a>
		   <a class="opcion-menu" href="menu">Menú de Pizzas</a>
		   <a class="opcion-menu" href="nosotros">Nosotros</a>
		   <a class="opcion-menu" href="galeria">Galer&iacute;a</a>
		   <a class="opcion-menu" href="contacto">Contacto</a>		
	</nav>
	<div id="top">
		<div id="logo"><a href="./"><img src="img/logo.png" /></a></div>
		<div id="datos">
		   <span class="dato">Encontranos en <strong>Sarmiento 906</strong></span>
		   <span class="dato">Delivery al (0291) <strong>4526-024</strong></span>
		   <span class="dato">
				<a href="https://www.facebook.com/pizzaalcuadrado" target="_blanck"><i class="fab fa-facebook-square ml-2"></i></a>
				<a href="http://instagram.com/pizaalcuadrado" target="_blanck"><i class="fab fa-instagram ml-2"></i></a>
				<a href="https://api.whatsapp.com/send?phone=5492914400810" target="_blanck"><i class="fab fa-whatsapp ml-2"></i></a>
			<span>
		 </div>
		 <nav id="menu">
		   <a class="opcion-menu" href="contacto">Contacto</a>
		   <a class="opcion-menu" href="galeria">Galer&iacute;a</a>
		   <a class="opcion-menu" href="menu">Menú de Pizzas</a>
		   <a class="opcion-menu" href="nosotros">Nosotros</a>
		 </nav>
	</div>
	<div id="firma">Copyright <?php echo date('Y'); ?> &#169; Pizza al cuadrado | Todos los derechos reservados | Dise&ntilde;ado por <a href="http://xeronweb.com/" target="_black">>>Xeron!</a></div>
</footer>

<script>
      $(document).ready(function()
      {
         //$("#exampleModalCenter").modal("show");
      });
</script>


<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Aviso importante</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Pizza al Cuadrado <b>abre sus puertas</b> desde el <b>lunes 13 de abril</b>. Los pedidos serán entregados <b>únicamente por delivery</b>. 
		<br>
		<br>
		Nos cuidamos entre todos <br>  #QuedateEnTuCasa
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar aviso</button>
      </div>
    </div>
  </div>
</div>